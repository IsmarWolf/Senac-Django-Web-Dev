
import delete as delete
from django.contrib import admin
from django.urls import path
from app.views import home, form, create, view, update, delete

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),  # Adicionando name='home' aqui
    path('form/', form, name='form'),
    path('create/', create, name='create'),
    path('view/<int:pk>/', view, name='view'),
    path('update/<int:pk>/', update, name='update'),
    path('delete/<int:pk>/', delete, name='delete')
]

