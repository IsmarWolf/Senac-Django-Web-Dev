from django.shortcuts import render, redirect
from app.forms import CarrosForm
from app.models import Carros
from django.http import JsonResponse
from django.core.paginator import Paginator


def home(request):
    data = {}
    search = request.GET.get('search')
    
    if search:
        all_cars = Carros.objects.filter(modelo__icontains=search)
    else:
        all_cars = Carros.objects.all()
    
    paginator = Paginator(all_cars, 2)  # 2 itens por página
    page = request.GET.get('page')
    data['db'] = paginator.get_page(page)
    return render(request, 'index.html', data)


def form(request):
    data = {}
    data['form'] = CarrosForm()
    return render(request, 'form.html', data)


def create(request):
    if request.method == 'POST':
        form = CarrosForm(request.POST)
        if form.is_valid():
            form.save()
            return JsonResponse({'status': 'success'})
        return JsonResponse({'status': 'error'})
    form = CarrosForm()
    return render(request, 'form.html', {'form': form})


def view(request, pk):
    data = {}
    data['db'] = Carros.objects.get(pk=pk)
    return render(request, 'view.html', data)


def update(request, pk):
    data = {}
    data['db'] = Carros.objects.get(pk=pk)
    data['form'] = CarrosForm(request.POST or None, instance=data['db'])
    
    if request.method == 'POST':
        if data['form'].is_valid():
            data['form'].save()
            return JsonResponse({'status': 'success'})
        return JsonResponse({'status': 'error'})
        
    return render(request, 'form.html', data)


def delete(request, pk):
    db = Carros.objects.get(pk=pk)
    db.delete()
    return redirect('home')